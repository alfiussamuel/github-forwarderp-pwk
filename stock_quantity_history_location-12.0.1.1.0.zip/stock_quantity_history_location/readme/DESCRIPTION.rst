This module allows to run an Inventory report or Inventory Valuation
report by location, for a past date or for current date.
