{
    "name": "Format input number",
    "version": "12.0.1.0.1",
    "summary": "Auto format decimal separator when user typing",
    "category": "Web",
    "depends": ["web"],
    "author": "Trình Gia Lạc",
    "website": "https://trinhgialac.com",
    "data": [
        "views/web_format_number.xml",
    ],
    "installable": True,
}
