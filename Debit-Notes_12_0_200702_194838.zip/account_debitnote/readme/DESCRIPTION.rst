In some situations, user need to add some service charge or some fees on top of what already invoiced.
This module add new feature to "Add Debit Note" from customer invoice / vendor bill
