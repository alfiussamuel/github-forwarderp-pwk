To use this module, you need to:

- Go to Invoicing -> Customers -> Invoices.
    - Create a new invoice and validate.
    - Click on Add Debit Note and fill in reasons. You can also specify an account date.
    - Click Add Debit Note, You will have a new one Invoice(Debit Note).
    - Validate Debit note.

You can also do the same with Vendor Bill.
