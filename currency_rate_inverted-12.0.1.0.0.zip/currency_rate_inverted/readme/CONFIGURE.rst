To convert amounts from one currency to another using the inverse method,
you have to go to *Accounting / Configuration / Accounting / Currencies*.
Then select the foreign currency that you wish to maintain inversion for
and set the flag *Inverted exchange rate*.
