* Eficent (www.eficent.com)
* Techrifiv Solutions Pte Ltd (www.techrifiv.com.sg)
* Statecraft Systems Pte Ltd (www.statecraftsystems.sg)
* Komit (Jean-Charles Drubay <jc@komit-consulting.com>)
* Alexey Pelykh <alexey.pelykh@brainbeanapps.com>
